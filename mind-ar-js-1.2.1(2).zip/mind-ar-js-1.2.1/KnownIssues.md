Mac (node v18) failed to install node-canvas

> brew install pkg-config cairo pango libpng jpeg giflib librsvg pixman

Ref: https://github.com/Automattic/node-canvas/issues/2025
